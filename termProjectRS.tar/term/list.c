/*****************************************************************************
 * 	
 * 	Riana Santos
 * 	Term Project
 * 	COEN 12 -- Spring 2022
 *
******************************************************************************/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<assert.h>
#include<stdbool.h>
#include "list.h"

typedef struct node{
	void **data;
	int count;
	int length;
	int first;
	struct node *next;
	struct node *prev;
}NODE;

typedef struct list{
	int nodeCount;
	int itemCount;
	NODE *head;
	NODE *tail;
}LIST;

//O(1)
LIST *createList(void){
	//creates a list pointer
	LIST *lp;
	lp = malloc(sizeof(LIST));
	assert(lp != NULL);
	//sets the amount of nodes and items to 0;
	lp->nodeCount = 0;
	lp->itemCount = 0;
	//creates the head and tail of list
	lp->head = malloc(sizeof(NODE));
	assert(lp->head != NULL);
	lp->tail = lp->head;
	lp->head->next = NULL;
	lp->head->prev = NULL;
	//returns the newly made list
	return lp;
}

//O(n)
void destroyList(LIST *lp){
	//ensures that the pointer isn't null
	assert(lp != NULL);
	//creates a node to traverse the list
	NODE *position = lp->head;
	//deletes the arrays of each node until end of list
	while(position != NULL){
		free(position->data);
		position = position->next;
	}
	//frees the list
	free(lp);
}

//O(1)
int numItems(LIST *lp){
	//ensures that the list isn't null
	assert(lp != NULL);
	//returns the number of items in the list
	return lp->itemCount;
}

//O(1)
void addFirst(LIST *lp, void *item){
	//ensures that the list and the item being added isn't null
	assert(lp != NULL && item != NULL);
	//creates a new node containing only the item being added
	if(lp->nodeCount == 0 || lp->head->count == lp->head->length){
		NODE *temp = malloc(sizeof(NODE));
		assert(temp != NULL);
		temp->first = 0;
		temp->length = 8;
		temp->count = 0;
		temp->data = malloc(sizeof(void*)*temp->length);
		assert(temp->data != NULL);
		temp->data[temp->first] = item;
		temp->prev = NULL;
		temp->next = NULL;
		//if the list is empty, sets the new node to be the head and the tail
		if(lp->nodeCount == 0){
			lp->head = temp;
			lp->tail = temp;
		}
		//if the head node is full, attaches the new node to the front of the list and sets the new node to be the head
		else if(lp->head->count == lp->head->length){
			lp->head->prev = temp;
			temp->next = lp->head;
			lp->head = temp;
		}
		//increments the total number of nodes in the list
		lp->nodeCount = lp->nodeCount + 1;
	}
	//determines the index to add the item
	int idx = (lp->head->first + lp->head->count) % lp->head->length;
	lp->head->data[idx] = item;
	//increments the total number of entries in the array and the list
	lp->head->count = lp->head->count + 1;
	lp->itemCount = lp->itemCount + 1;
}

//O(1)
void addLast(LIST *lp, void *item){
	//ensures that the list and the item being added isn't null
	assert(lp != NULL && item != NULL);
	//creates a new node
	if(lp->nodeCount == 0 || lp->tail->count == lp->tail->length){
		NODE *temp;
		temp = malloc(sizeof(NODE));
		assert(temp != NULL);
		temp->length = 8;
		temp->first = 0;
		temp->data = malloc(sizeof(void*)*temp->length);
		assert(temp->data != NULL);
		temp->count = 0;
		temp->prev = NULL;
		temp->next = NULL;
		//if the list is empty, sets the new node to be the head and the tail
		if(lp->nodeCount == 0){			
			lp->head = temp;
			lp->tail = temp;
		}
		//if the tail node is full, attaches the new node to the end of the list and sets the new node to be the tail
		else if(lp->tail->count == lp->tail->length){
			temp->prev = lp->tail;
			lp->tail->next = temp;
			lp->tail = temp;
		}
		//increments the amount of nodes in the list
		lp->nodeCount = lp->nodeCount + 1;
	}
	//finds the place for the item to be added and places it in the array
	int idx = (lp->tail->first + lp->tail->count) % lp->tail->length;
	lp->tail->data[idx] = item;
	//increments the total number of entries in the array and the list
	lp->tail->count = lp->tail->count + 1;
	lp->itemCount = lp->itemCount + 1;
}

//O(1)
void *removeFirst(LIST *lp){
	//ensures list pointer isn't null and that there is something to remove
	assert(lp != NULL && lp->itemCount > 0);
	void *dataDel;
	//if the head node is empty
	if(lp->head->count == 0){
		//reassigns the head and 
		NODE *deleted = lp->head;
		lp->head = lp->head->next;
		lp->head->prev = NULL;
		//deletes the node and decrements the amount of nodes in the list
		free(deleted);
		lp->nodeCount = lp->nodeCount - 1;
	}
	//saves the deleted data to return later
	dataDel = lp->head->data[lp->head->first];
	lp->head->data[lp->head->first] = NULL;
	//changes the first slot of the array
	lp->head->first = (lp->head->first + 1) % lp->head->length;
	//decrements the total entries in the array and the list
	lp->head->count = lp->head->count - 1;
	lp->itemCount = lp->itemCount - 1;
	//returns the data that was deleted
	return dataDel;
}

//O(1)
void *removeLast(LIST *lp){
	//ensure that the list pointer isn't null and there is something to delete
	assert(lp != NULL && lp->itemCount > 0);
	void *dataDel;
	//if the tail node is empty, delete the node and reassign tail node
	if(lp->tail->count == 0){
		NODE *deleted = lp->tail;
		lp->tail = lp->tail->prev;
		lp->tail->next = NULL;
		free(deleted);
		//decrement the amount of nodes in the list
		lp->nodeCount = lp->nodeCount - 1;
	}
	//find where to save the deleted data
	int idx = (lp->tail->first + lp->tail->count - 1) % lp->tail->length;
	dataDel = lp->tail->data[idx];
	//decrement the amount of entries in the tail and the total amount of entries in the list
	lp->tail->count = lp->tail->count - 1;
	lp->itemCount = lp->itemCount - 1;
	//returns the data that was deleted
	return dataDel;
}

//O(n)
void *getItem(LIST *lp, int index){
	//ensures that the list pointer isn't null and that the index is within range
	assert(lp != NULL && index >= 0 && index < lp->itemCount);
	//creates a temporary node to traverse the list
	NODE *temp = lp->head;
	int i, x;
	x = 0;
	//goes through the arrays of each node to find the item
	for(i = 0; i < lp->itemCount; i+=temp->count){
		if(index < temp->count){
			x = index;
			break;
		}
		else{
			index-= temp->count;
		}
		temp = temp->next;
	}
	//returns the data found
	int idx = (temp->first + x) % temp->length;
	return temp->data[idx]; 
}

//O(n)
void setItem(LIST *lp, int index, void *item){
	//ensures that the list pointer and the item isn't null
	assert(lp != NULL && item != NULL);
	int counter = index;
	//creates a node to traverse the list
	NODE *temp = lp->head;
	while(temp != NULL){
		//places item in desired index
		if((counter - temp->count) < 0){
			temp->data[(temp->first + counter) % temp->length] = item;
			return;
		}
		//else moves through to the next array or node
		counter = counter - temp->count;
		temp = temp->next;
	}
}
